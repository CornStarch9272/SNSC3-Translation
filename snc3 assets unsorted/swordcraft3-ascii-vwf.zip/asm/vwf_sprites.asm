.definelabel DrawStrSpriteGlyph,0x08002CB4

; This is the function that draws glyphs as sprites.
; We extend to support ASCII/etc.
.org 0x080036F8
.region 0x0800379C-.,0x00
; Args: uint32_t *dst, const uint16_t *str, int8_t *widths
; Returns: uint16_t charsDrawn
.func DrawStrSpriteGlyphs
push r4-r7,r14
mov r7,r10
mov r6,r9
mov r5,r8
push r5-r7

; Save out the important parameters.
mov r10,r0
mov r4,r1
mov r9,r2

; This will count drawn characters.
mov r7,0
; And a trick: this is where we push the str for a name.
; We reuse our main loop and just swap the pointer.
mov r5,0
; Fixed width flag.
mov r6,0xFF

; r0=FREE, r1=FREE, r2=FREE, r3=FREE, r4=str, r5=oldStr, r6=widthOverride, r7=charsWritten
; r8=FREE, r9=widths, r10=dst, r12=FREE?, r14=FREE

@@nextChar:
; Read the first byte.
ldrb r0,[r4]
add r4,r4,1

; If it's 7F or lower, single byte (also end of string.)
cmp r0,0x7F
blo @@handleAscii
beq @@handleWidthControl

; Grab the high byte, but don't merge yet.
ldrb r1,[r4]
add r4,r4,1
lsr r2,r1,4

; 87 7? means control code (ignored here.)
cmp r0,0x87
bne @@checkNameCode
cmp r2,0x07
beq @@nextChar

; 83 C? means name code (output name variable.)
@@checkNameCode:
cmp r0,0x83
bne @@handleJIS
cmp r2,0x0C
bne @@handleJIS

; Okay, this is a name.  Grab the index * 9.
lsl r1,r1,28
lsr r1,r1,28
; (x * 8) + x == x * 9
lsl r0,r1,3
add r0,r0,r1
; Double, since it's 9 shorts.
lsl r0,r0,1

; Save old str.
mov r5,r4
; This is where the names are.
ldr r4,=0x03005580
add r4,r4,r0

; Okay, we're ready, process chars.
b @@nextChar

@@handleAscii:
cmp r0,0
beq @@doneStr

mov r1,0
; Fall-through.

@@handleJIS:
; Combine to a single character code.
lsl r1,r1,8
orr r0,r1

; Now grab the glyph.
bl LookupGlyph
; That returned the width in r1.
mov r8,r1

; Prep the dst, always a multiple of 4 tiles.
lsl r1,r7,7
add r1,r10

bl DrawStrSpriteGlyph
add r7,r7,1

; Okay, get the last width offset - 1.
sub r3,r7,2
add r3,r9

; Set r2 to the width (applying override if needed.)
mov r2,r6
cmp r2,0xFF
bne @@keepFixedWidth
mov r2,r8
@@keepFixedWidth:
; Sum this width with the last one.  Subtract 12 first, since that's the sprite default.
sub r2,12
cmp r7,1
bls @@skipAddFirst
mov r1,0
ldsb r1,[r3,r1]
add r2,r2,r1
@@skipAddFirst:
strb r2,[r3,1]
b @@nextChar

@@handleWidthControl:
; Read the next byte, which will be the fixed width.
ldrb r6,[r4]
add r4,r4,1
b @@nextChar

@@doneStr:
mov r4,r5
mov r5,0
; If it's not zero, we finished a name.  Back to the str.
cmp r4,0
bne @@nextChar

mov r0,r7

pop r1-r7
mov r8,r1
mov r9,r2
mov r10,r3
pop r15
.pool
.endfunc
.endregion

.org 0x0800B730
.region 0x0800B8F4-.,0x00
; Args: uint16_t index, const uint16_t *str
.func DrawStrSprites
push r4-r7,r14
; We can't have more than 8 characters (see +0x0174 buffer), but let's have extra space.
sub sp,12

; Convert index into an offset by bytes, masking first.
lsl r0,r0,16
lsr r0,r0,16
; 0x019C = 0x67 << 2
mov r2,0x67
lsl r2,r2,2
mul r0,r2

; Add the base and save the pointer.
ldr r6,=0x030056C0
add r6,r6,r0

; Update a flag (?) on the struct.
mov r0,1
strb r0,[r6,9]
; r2 is still 0x19C, sub 4 to 0x198.
sub r2,r2,4
; Put the string in at the end.
str r1,[r6,r2]
; Save the 0x198 for later as 0x194.
sub r5,r2,4

; This has the current target pos and offset.  Sum after aligning.
ldr r7,=0x03005180 + 0x03A8 ; 0x03005528
ldr r4,[r7,0]
ldr r2,[r7,8]
mov r0,3
bic r2,r0
add r4,r4,r2

; Now let's draw some glyphs.  r1 is still str.
mov r0,r4
mov r2,sp
bl DrawStrSpriteGlyphs

; We saved 0x194 in r5 earlier.  Not sure what this value is, used for the next func.
ldr r1,[r6,r5]

; Store the glyph count.
strb r0,[r6,2]
; We'll need it after this call too, so save it away.
mov r5,r0
; And also convert to bytes for r2.
lsl r2,r0,7

; Finally r0 is just dst, which we stashed in r4.
mov r0,r4
; Not sure what this does exactly.
bl 0x08006BA4

; Now move forard that offset by bytes written.
lsl r0,r5,7
ldr r1,[r7,8]
add r1,r1,r0
str r1,[r7,8]

; 0x55 << 2 = 0x154
mov r1,0x55
lsl r1,r1,2
add r1,r1,r6

; We'll need this a bunch soon.
mov r3,0
; Okay, start filling in some struct fields.  Not sure the point of all of these.
str r3,[r1,0]
; This is still bytes written.
str r0,[r1,4]
strh r3,[r1,8]
; Convert r5 (charsWritten) to tile count.
lsl r0,r5,2
strh r0,[r1,10]
strh r0,[r1,12]
strh r3,[r1,14]
; Copy the value at +0x0194 to +0x0164.  Keep it in r2.
ldr r2,[r1,64]
str r2,[r1,16]
str r3,[r1,20]
; Store a pointer to +0x0170 at +0x016C.
mov r0,r1
add r0,28
str r0,[r1,24]
str r5,[r1,28]

; We update the next part for each character.  But prep a reused value first.
ldrb r4,[r6,12]
lsl r4,r4,12

; Trick: we fill in reverse, 4 bytes for each character (r5 is # of characters.)
lsl r7,r5,2
; It's at +0x0174, so we add 0x20 to r1 temporarily.
add r1,0x20

@@nextCharInfo:
sub r7,r7,4
bmi @@charInfoDone

; Construct: { (uint8_t)0, (uint8_t)0x40, (uint16_t)(r7 | r4) }
add r0,r7,r4
lsl r0,r0,8
add r0,0x40
lsl r0,r0,8
; And write it all in one shot.
str r0,[r1,r7]
b @@nextCharInfo

@@charInfoDone:
sub r1,0x20

; At this point, all the args for 08009334 have been prepared except r0.
; Not entirely sure what this does, but presumably uses all those params we set.
ldrb r0,[r6,13]
bl 0x08009334

; Now a quick chain of funcs, which seems to prepare the sprites maybe?
mov r0,3
mov r1,7
bl 0x08001D3C
ldrb r1,[r6,15]
bl 0x08001D78
; This ends up as a value pointing into the ROM...
mov r2,r0
ldrb r0,[r6,14]
ldrb r1,[r6,13]
bl 0x0800A630

; Alright, one more loop for each character to prep the sprite info.
cmp r5,0
beq @@doneSprites

mov r7,0
mov r4,r6
add r4,20

@@nextSprite:
mov r0,r4
bl 0x08009F0C

; This seems to place the tiles and pos offset based on r2?
mov r0,r4
ldrb r1,[r6,14]
mov r2,r7
ldrb r3,[r6,16]
bl 0x08009F50

mov r0,r4
; These are the X,Y coordinates of the string start.
; They are automatically offset by the character at a standard width.
mov r3,4
ldsh r1,[r6,r3]
mov r3,6
ldsh r2,[r6,r3]

cmp r7,0
beq @@skipAdjust

; Here's where we apply our VWF.  The sum width offset so far is at sp[pos - 1].
; This sum already subtracts 12 for each character, so it's always negative.
mov r3,sp
sub r3,r3,1
ldsb r3,[r3,r7]
; Originally, the game makes the first letter slightly shorter (not sure why?)
; TODO: Keeping that for now...
sub r3,r3,1
; TODO: How do we know it's doubled?  Sometimes it isn't it seems like?
add r1,r1,r3
add r1,r1,r3

@@skipAdjust:
bl 0x0800A678

mov r0,r4
ldrb r1,[r6,12]
mov r2,1
bl 0x0800A6C0

mov r0,r4
mov r1,1
lsl r1,r1,8
bl 0x0800A6CC

add r4,0x28
add r7,r7,1
cmp r7,r5
blo @@nextSprite

@@doneSprites:
; Technically two bytes, let's simplify as a halfword store.
mov r0,2
strh r0,[r6,0]

add sp,12
pop r4-r7
pop r0
bx r0
.pool
.endfunc
.endregion
